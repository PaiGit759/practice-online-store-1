// module.exports = {
//     url: "mongodb://localhost:27017/online_store_db"
//   };

 
  module.exports = {
    HOST: "localhost",
    PORT: 27017,
//    DB: "bezkoder_db"
    DB: "online_store_db"

  };