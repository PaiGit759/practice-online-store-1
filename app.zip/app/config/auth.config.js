module.exports = {
    secret: "practice-secret-key"
  };